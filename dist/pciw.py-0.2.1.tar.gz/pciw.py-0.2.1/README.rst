.. _pciwpy:

pciw.py
=======

This module can obtain **full information** about the ``CPU``, ``RAM``,
``GPU``, ``BIOS``, ``motherboard`` and ``monitors``. So far, it **only
works fully** on a ``Windows`` system. `Read more on Github...`_

Install
-------

::

    pip install py-cpuinfo screeninfo psutil

Example
-------

.. code:: python

    from pciw import pciw

    cpu, ram, bios, gpu, motherboard, monitors = pciw.CPU(), pciw.RAM(), pciw.BIOS(), pciw.GPU(), pciw.Motherboard(), pciw.Monitors()

Author
------

-  Roman Slabicky

    -  `Vkontakte`_
    -  `GitHub`_

.. _Read more on Github...: https://github.com/romanin-rf/pciw.py
.. _Vkontakte: https://vk.com/romanin2
.. _GitHub: https://github.com/romanin-rf
